﻿public class Statics
{
    public static float distance = 10;
    public static float nextPosition = 30;
    public static float startPosition = nextPosition;



}


