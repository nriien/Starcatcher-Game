﻿
public class StaticVars {

    public static float distance = 10;
    public static float nextSectionPosition =10f;
}